# Antonette Juaban — Portfolio Website

Static portfolio website prepared for independent hosting.

## Files
- `index.html` — main portfolio page
- `styles.css` — site styling
- `script.js` — menu, contact modal, WhatsApp/email links, and year
- `images/profile.jpg` — profile image
- `robots.txt` — crawler instructions
- `sitemap.xml` — sitemap for search engines
- `vercel.json` — optional Vercel headers/configuration

## Target custom domain
`anjuabanyourva.com`

## Option 1 — Vercel (recommended for this static site)
1. Create a Vercel account at https://vercel.com/.
2. Create a new project and upload/import this folder (or connect a Git repository).
3. Deploy it as a static site; no build command is required.
4. In the Vercel project, open **Settings → Domains** and add `anjuabanyourva.com`.
5. Vercel will show the DNS records required for your domain registrar. Add those records at the registrar where you purchased the domain.
6. Wait for DNS verification and HTTPS to finish provisioning.

## Option 2 — Netlify
1. Create an account at https://www.netlify.com/.
2. Deploy the folder as a static site using Netlify Drop or a connected Git repository.
3. Add `anjuabanyourva.com` under the site's domain settings.
4. Follow Netlify's displayed DNS instructions at your domain registrar.

## Important
The website files do not purchase or register the domain. You must own/control `anjuabanyourva.com` (or another domain you choose) through a domain registrar and point its DNS to your hosting provider.

Before publishing, verify the contact details and external profile links in `index.html` and `script.js` are the ones you want public.
