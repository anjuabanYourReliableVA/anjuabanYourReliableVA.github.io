(function(){
  var WA="639278559483", MAIL="chailynkim@gmail.com";
  var dlg=document.getElementById('hire');
  var name=document.getElementById('f-name'), msg=document.getElementById('f-msg');
  var wa=document.getElementById('c-wa'), mail=document.getElementById('c-mail');

  function text(){
    var n=name.value.trim(), m=msg.value.trim();
    return "Hi Antonette, "+(n?"this is "+n+". ":"")+"I found your website and I'd like to talk about hiring you as a Virtual Assistant."+(m?"\n\nWhat I need help with: "+m:"");
  }
  function refresh(){
    wa.href="https://wa.me/"+WA+"?text="+encodeURIComponent(text());
    mail.href="mailto:"+MAIL+"?subject="+encodeURIComponent("Hiring inquiry from your website")+"&body="+encodeURIComponent(text());
  }
  name.addEventListener('input',refresh); msg.addEventListener('input',refresh); refresh();

  function open(){
    closeMenu();
    if(dlg.showModal){dlg.showModal();} else {dlg.setAttribute('open','');}
  }
  function close(){ if(dlg.close){dlg.close();} else {dlg.removeAttribute('open');} }
  document.querySelectorAll('[data-hire]').forEach(function(b){b.addEventListener('click',open)});
  document.getElementById('hire-close').addEventListener('click',close);
  dlg.addEventListener('click',function(e){ if(e.target===dlg) close(); });
  dlg.querySelectorAll('.choice').forEach(function(a){a.addEventListener('click',function(){setTimeout(close,200)})});

  var burger=document.getElementById('burger'), menu=document.getElementById('mmenu');
  function closeMenu(){menu.classList.remove('open');burger.setAttribute('aria-expanded','false')}
  burger.addEventListener('click',function(){
    var o=menu.classList.toggle('open'); burger.setAttribute('aria-expanded',o?'true':'false');
  });
  menu.querySelectorAll('a').forEach(function(a){a.addEventListener('click',closeMenu)});

  var links=[].slice.call(document.querySelectorAll('#navlinks a'));
  var map={};
  links.forEach(function(a){map[a.getAttribute('href').slice(1)]=a});
  if('IntersectionObserver' in window){
    var io=new IntersectionObserver(function(es){
      es.forEach(function(e){
        if(e.isIntersecting){links.forEach(function(l){l.classList.remove('active')}); if(map[e.target.id]) map[e.target.id].classList.add('active');}
      });
    },{rootMargin:'-45% 0px -50% 0px'});
    Object.keys(map).forEach(function(id){var s=document.getElementById(id); if(s) io.observe(s);});
  }
  document.getElementById('yr').textContent=new Date().getFullYear();
})();
